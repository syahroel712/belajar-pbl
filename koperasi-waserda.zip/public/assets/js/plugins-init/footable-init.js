jQuery(function($){
	$('#table').footable();
});